const path = require('path');
const http = require('http');
const express = require('express');
const mongoose = require('mongoose');
const Booking = require('./model/booking');
const Mail = require('./model/mail');
const Room = require('./model/room');
const User = require('./model/user');
const jwt = require('jsonwebtoken');
const checkAuth = require('./middleware/check-auth');
const nodemailer = require("nodemailer");
const bodyParser = require('body-parser');
const debug = require("debug")("node-angular");
const app = express();

const mongoURI = 'mongodb+srv://joel:hAZCP4aDZilM38oq@cluster0.0u0ez.mongodb.net/jersam?retryWrites=true&w=majority';
const conn = mongoose.createConnection(mongoURI, { useCreateIndex: true, useUnifiedTopology: true, useNewUrlParser: true });

mongoose.connect('mongodb+srv://joel:hAZCP4aDZilM38oq@cluster0.0u0ez.mongodb.net/jersam?retryWrites=true&w=majority', { useCreateIndex: true, useUnifiedTopology: true, useNewUrlParser: true }, () => {
    console.log('database connected!!');
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/images', express.static(path.join('images')));
app.use('/', express.static(path.join(__dirname, 'jersam')));

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    next();
});

const imagePath = path.join(__dirname, '/images');

const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
        type: 'OAuth2',
        user: 'jersamgb@gmail.com',
        clientId: '713513589622-415fkr13nqoedbg92htkotlsht1ogc2m.apps.googleusercontent.com',
        clientSecret: 'dAYc9RxXuymrOUhddVhwBPHX',
        refreshToken: '1//04JamQGav3hjcCgYIARAAGAQSNwF-L9IrSF_hyWIk6TPv4GKkN8m5eSXy16Nmjj00TVJ3IZqwqWWwHt_vccGv_MTc3BfDmK_T-qQ',
        accessToken: 'ya29.a0AfH6SMAhE5sRSTKS4CqcW_hXTiRknbXWNhXgAV35VJ0XDMrgQW5S1QTeW9_wmVpp_ZlKp8Q-4n4_vR8gD0X-f3tueOKL4ttkV49cA_hde_3NLtrbTvv9vXUI79Ls1WSlFfWcPkTgn9HUaoqLGxFuySPZmB-Pa69sNNg',
    }
});

// BOOK ROOM
app.post('/api/sendConfirmation', (req, res, next) => {
    const booking = new Booking({
        ...req.body.fullUserBookingDetails
    })

    booking.save(booking).then((document) => {
        saveBookingDetails(req, res);
    });
})

// SUBSCRIBER
app.post('/api/sendMail', (req, res, next) => {
    const mail = new Mail({
        ...req.body
    })

    mail.save(mail).then((document) => {
        res.status(201).json({
            message: 'successfully saved!!',
            data: true
        });
    });
})

// CONTACT US
app.post('/api/sendMailiMessage', (req, res, next) => {
    const mailOptions = {
        from: req.body.email,
        to: 'JerSam Hotel <jersamgb@gmail.com>',
        subject: req.body.subject,
        text: req.body.message
    }

    transporter.sendMail(mailOptions, (error, response) => {
        if (error) {
            res.status(200).json({
                message: error,
                data: false
            });
        } else {
            if (response.response) {
                res.status(201).json({
                    message: 'successfully saved!!',
                    data: true
                });
            }
        }
    });
})

// GET AVAIALBLE ROOMS AND PRICES
app.get('/api/getRooms', (req, res, next) => {
    Room.find()
        .then((documents) => {
            res.status(200).json({
                message: 'successfully fetched!!',
                data: documents
            });
        })
})

// UPDATE ROOM PRICES 
app.post('/api/updateRoomPrice', (req, res, next) => {
    try {
        const rooms = new Room([]);
        rooms.collection.drop()
            .then(() => {
                rooms.collection.insertMany(req.body)
                    .then(() => {
                        res.status(200).json({
                            message: 'Updated successfully!!',
                            data: true
                        });
                    }).catch(() => {
                        res.status(500).json({
                            data: false
                        });
                    })
            }).catch(() => {
                res.status(500).json({
                    data: false
                });
            });
    } catch (error) {
        res.status(500).json({
            data: false
        });
    }
})

// CHECK ROOM AVAILABILITY
app.post('/api/checkRoomAvailability', (req, res, next) => {
    const from = new Date(new Date(req.body.from).setHours(02, 00, 00));
    const to = new Date(new Date(req.body.to).setHours(02, 00, 00));
    Booking.find({
        from: { $gte: from },
        to: { $lte: to },
        roomType: req.body.roomType
    }).then((documents) => {
        res.status(200).json({
            message: 'Orders fetched!!',
            data: documents
        });
    })
})

// LOGIN
app.post('/api/login', (req, res, next) => {
    User.findOne({ email: req.body.email, password: req.body.password })
        .then(user => {
            if (!user) {
                return res.status(401).json({
                    message: 'Identifiants utilisateur incorrects',
                })
            }
            const token = jwt.sign({
                    email: user.email,
                    userType: user.userType,
                    userId: user._id
                },
                'secret_code', { expiresIn: '1h' });
            res.status(200).json({
                token: token,
                expiresIn: 3600,
                data: true
            })
        }).catch((err) => {
            return res.status(500).json({
                message: "Une erreur s'est produite. Veuillez réessayer",
            })
        })
})

// GET BOOKING -AUTH
app.get('/api/getBookings', checkAuth, (req, res, next) => {
    Booking.find()
        .then((documents) => {
            res.status(200).json({
                message: 'successfully fetched!!',
                data: documents
            });
        })
})

// GET SUBSCRIBERS -AUTH 
app.get('/api/getSubscribers', checkAuth, (req, res, next) => {
    Mail.find()
        .then((documents) => {
            res.status(200).json({
                message: 'successfully fetched!!',
                data: documents
            });
        })
})

// SEARCH USER DETAILS 
app.get('/api/search/:searchText', checkAuth, (req, res, next) => {
    var query = {
        $or: [
            { payReferenceNumber: { '$regex': req.params.searchText } }
        ]
    }

    Booking.findOne(query)
        .then((document) => {
            res.status(200).json({
                message: 'successfully fetched!!',
                data: document
            });
        })
})

// SEND BOOKING CONFIRMATION TO EMAIL
function saveBookingDetails(req, res) {
    console.log('Image path', imagePath);
    const mailOptions = {
        from: 'JerSam Hotel <jersamgb@gmail.com>',
        to: req.body.partialbookingDetails.to,
        subject: req.body.partialbookingDetails.subject,
        html: req.body.partialbookingDetails.body,
        attachments: [{
                filename: 'room.jpg',
                path: imagePath + '/room.jpg'
            },
            {
                filename: 'room_2.jpg',
                path: imagePath + '/room_2.jpg'
            }
        ]
    }

    transporter.sendMail(mailOptions, (error, response) => {
        if (error) {
            console.log('error req', error);
            res.status(200).json({
                message: error,
                data: false
            });
        } else {
            if (response.response) {
                console.log('response succ', response.response);
                res.status(200).json({
                    message: response.response,
                    data: true
                });
            }
        }
    });
}

app.use((req, res, next) => {
    res.sendFile(path.join(__dirname, "jersam", "index.html"))
})

module.exports = app;