const mongoose = require('mongoose');

const bookingSchema = mongoose.Schema({
    from: Date,
    to: Date,
    adult: String,
    kid: String,
    numberOfRooms: String,
    name: String,
    surname: String,
    email: String,
    address: String,
    selectedPaymenMethod: String,
    roomType: String,
    bookingCreatedDate: Date,
    payOnArrival: Boolean,
    user: String,
    payReferenceNumber: String,
    amount: String,
}, {
    versionKey: false
});

module.exports = mongoose.model('Booking', bookingSchema);