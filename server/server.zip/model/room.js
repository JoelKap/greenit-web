const mongoose = require('mongoose');

const roomSchema = mongoose.Schema({
    roomType: String,
    amount: Number,
}, {
    versionKey: false
});

module.exports = mongoose.model('Room', roomSchema);