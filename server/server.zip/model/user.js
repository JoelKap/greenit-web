const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    email: String,
    password: String,
    userType: String,
}, {
    versionKey: false
});

module.exports = mongoose.model('User', userSchema);