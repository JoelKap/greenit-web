const mongoose = require('mongoose');

const quoteSchema = mongoose.Schema({
    email: String,
    selectedService: String,
    typeOfBusiness: String,
    projectType: String,
    pageNumbers: String,
    amount: String,
    dateCreated: Date,
}, {
    versionKey: false
});

module.exports = mongoose.model('Quote', mailSchema);
