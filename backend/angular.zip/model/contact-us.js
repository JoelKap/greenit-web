const mongoose = require('mongoose');

const contactSchema = mongoose.Schema({
    name: String,
    email: String,
    message: String,
    createdDate: Date,
}, {
    versionKey: false
});

module.exports = mongoose.model('Contact', mailSchema);