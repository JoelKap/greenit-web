const path = require('path');
const express = require('express');
const nodemailer = require("nodemailer");
const bodyParser = require('body-parser');
// const debug = require("debug")("node-angular");
// const http = require('http');
var port = process.env.PORT || 3000;
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/', express.static(path.join(__dirname, 'angular')));

// app.use((req, res, next) => {
//     res.setHeader('Access-Control-Allow-Origin', '*');
//     res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
//     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
//     next();
// });

const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
        type: 'OAuth2',
        user: 'joelkapuku@gmail.com',
        clientId: '598496570087-eatebl9qga0t8q4oj8ljv03lcg6vu5a4.apps.googleusercontent.com',
        clientSecret: 'Li4yobcg748OH4cuzNI0_76E',
        refreshToken: '1//04YwjECFCDVX9CgYIARAAGAQSNwF-L9Ir02oILMAM6dlZEP1MrWnDMvbRxCP_E7q6ars9eAzx-O6zbHmGRb119aa2wiRBpwZds1g',
        accessToken: 'ya29.a0AfH6SMA5BXtw7BUe9PCJVWLxbkNb8EdDjgUtf7lnUTU7ALiMFiVLMdm4m17uDD7imciQck4DvAAdAGX5EPR-zDoyKPJDiRwqn_Y43Vc4gjRycL87RGosvxoBWjeNUcbt78W1JtnS5gr0tME8qySX9-Sk6qCOgBXS7xo',
    }
});

// CONTACT US
app.post('/api/sendMail', (req, res, next) => {
    console.log('user contact', req.body);
    const mailOptions = {
        from: req.body.email,
        to: 'SBIT Message <joelkapuku@gmail.com>',
        subject: 'SBIT ENQUIRIES',
        html: 'User:' + ' ' + req.body.name + '<br/><br/>' + req.body.message
    }

    transporter.sendMail(mailOptions, (error, response) => {
        if (error) {
            console.log('error response', error);
            res.status(200).json({
                message: error,
                data: false
            });
        } else {
            if (response.response) {
                console.log('success response', response.response);
                res.status(201).json({
                    message: 'successfully saved!!',
                    data: true
                });
            }
        }
    });
})

// SEND USER QUOTE
app.post('/api/userQuote', (req, res, next) => {
    console.log('user quote', req.body);
    const mailOptions = {
        from: req.body.email,
        to: 'SBIT Message <joelkapuku@gmail.com>',
        subject: 'user QUOTE',
        html: JSON.stringify(req.body)
    }

    transporter.sendMail(mailOptions, (error, response) => {
        if (error) {
            res.status(200).json({
                message: error,
                data: false
            });
        } else {
            if (response.response) {
                res.status(201).json({
                    message: 'successfully saved!!',
                    data: true
                });
            }
        }
    });
})

app.use((req, res, next) => {
    res.sendFile(path.join(__dirname, "angular", "index.html"))
})

app.listen(port, function() {});
console.log('Server running at http://127.0.0.1:' + port + '/');

// module.exports = app;